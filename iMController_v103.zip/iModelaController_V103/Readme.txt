***************************************************************
                 iModela Controller
***************************************************************

WELCOME TO iModela Controller!

We recommend that you first read through this document to obtain a better understanding of iModela Controller.
This document provides an overview of the programs and their system requirements.

The explanations here assume that you are already familiar with using in Windows. For further information about using Windows, please refer the user's manual from Microsoft Corp.

If you are reading this file with Notepad, then go to the Edit menu and click "WordWrap" to select word-wrapping and make the displayed text easier to read.


Table of Contents

1.  Summary
2.  System requirements
3.  Installation


* "Windows(R)" is registered trademark or trademark of Microsoft(R) Corporation in the United States and/or other countries.
Other company and product names appearing herein are trademarks or registered trademarks of their respective holders.

Copyright (C) 2011, 2012 Roland DG Corporation


R2-120213


========================================================
1.  Summary
========================================================

iModela Controller is a control program for operating and making settings for modeling machines from Roland DG Corp.
It displays current information about the modeling machine on a computer screen in real time.
This program is integrated with the modeling machine. You should always run it when you use the modeling machine.


========================================================
2.  System requirements
========================================================

- Microsoft(R) Windows XP (32-bit or 64-bit ), Windows Vista (32-bit or 64-bit ) or Windows 7 (32-bit or 64-bit ) operating system
  * As this software is a 32-bit application, it runs on WOW64 (or Windows-On-Windows 64) under the 64-bit version of Windows.
- The minimum required CPU for the operating system
- The minimum amount of required RAM for the operating system
- 5 Mbytes or more of free hard disk space for installation
- 16-bit color (High Color) or higher video card with a resolution of 1024 x 768


========================================================
3.  Installation
========================================================

To install the iModela Controller programs, please follow the procedures described below. You cannot run the iModela Controller programs directly from this installation disk.


--------------------
- Installing the program from CD-ROM
Follow the instructions on the setup menu on the CD-ROM to install and set up.

- Installing the program from Setup.exe(Web download)
Follow the instructions on the Setup.exe to install and set up.

========================================================

If you have questions or problems, please contact your local vendor or Roland sales center.
